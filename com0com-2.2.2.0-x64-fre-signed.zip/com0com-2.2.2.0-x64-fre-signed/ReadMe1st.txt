1. This package contains com0com.sys and com0com.cat that were built and
   signed by Steven William Hatchett.

The driver was not been tested by Microsoft WHQL so possible you will get
Security Alerts while adding new port pairs.

Windows Server 2003

  To suppress Security Alerts go to

    My Computer->Properties->Hardware->Driver Signing

  and choose Ignore option.

  NOTE: Suppressing Security Alerts will impair computer security.

Windows Vista/Windows Server 2008/Windows 7

  To suppress Security Alerts click
 
    Always trust software from "Steven William Hatchett".


2. This package contains setupc.exe and setupg.exe marked as
   "require administrative access" so Turning off UAC is not required.
